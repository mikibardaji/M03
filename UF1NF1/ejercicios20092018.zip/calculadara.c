#include <stdio.h>


int main()
{
	int valor1, valor2;

	printf("pon el valor1: ");
	/* scanf espera el valor introducido por teclado 
	y lo guarda en la variable que digamos se pone con &(direccion memoria) */
	scanf("%d",&valor1); /*aqui valor1 va a tener 
	el valor introducido por teclado*/
	printf("has introducido el valor %d \n",valor1);
    printf("pon el valor2: "); 
	scanf("%d",&valor2); /*aqui valor2 va a tener otro valor*/ 
	int suma = valor1 + valor2; /*operacion*/
	printf("El resultado es %d",suma); /* lo muestro por pantalla*/
	/* int -> %d, long %ld
	   float -> %f, double %lf
	   character -> %c */
	
	
	return 0;	
}
