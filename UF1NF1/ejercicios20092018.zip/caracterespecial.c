#include <stdio.h>

/*
 realizamos operaciones
*/
int main()
{
	printf("Vamos a escribir caracteres especiales \n");
	printf("--> \\");
	printf("\n"); /* un retorno de carro*/
	printf("--> /");
	printf("\n"); /* un retorno de carro*/
	
	printf("--> \" comilla doble");
	printf("\n"); /* un retorno de carro*/
	
	printf("--> \' comilla simple");
	printf("\n"); /* un retorno de carro*/
	
	printf("tabulacion\ttabulado");
	printf("\n"); /* un retorno de carro*/
	return 0;
	
}
