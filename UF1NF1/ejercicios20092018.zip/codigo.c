#include <stdio.h>

/*
 realizamos operaciones
*/
int main()
{
	int mivariable,mivariable2,v3;
	mivariable = 12;
	mivariable2 = 15;
	v3 = mivariable - mivariable2;
	printf("resta : %d \n",v3);
	/* la \n es para imprimir el retorno de carro*/
	/* El primer %d es para la primera variable y %d para la segunda*/
	printf("primer valor: %d segundo: %d \n",mivariable,mivariable2);
	/* a partir de esta linea v3 valdra la suma de las otras dos*/
	v3 = mivariable + mivariable2;
	printf("El resultado es: %d \n",v3);
	/* a partir de esta linea v3 valdra la resta de las otras dos*/
	v3 = mivariable - mivariable2;
	printf("El resultado es: %d \n",v3);
	mivariable = 22;
	mivariable2 = 5;
	v3 = mivariable / mivariable2;
	printf("El cociente es: %d \n",v3);
	v3 = mivariable % mivariable2;
	printf("El resto es: %d",v3);
	float dividir = mivariable / mivariable2;
	printf("La division es: %f \n",dividir);
	return 0;
}
