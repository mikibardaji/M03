#include <stdio.h>

/* imprimir por pantalla todo tipo de variables */
int main()
{
	int entero=2;
	printf("entero : %d \n",entero);
	float decimal = 3.56;
	printf("decimal : %f \n",decimal);
	/* long, double, char*/
	long enterolargo = 45456095;
	printf("long entero largo : %ld \n",enterolargo);
	double decimallargo = 349494.34566;
	printf("decimal largo : %lf \n",decimallargo);
	char caracter = 'A';
	printf("caracter : %c \n",caracter);
	caracter = 'D';
	printf("caracter : %c \n",caracter);
	return 0;
}
