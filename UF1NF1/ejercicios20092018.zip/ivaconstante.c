#include <stdio.h>

#define IVA 0.21
#define letra 'C'


int main()
{
	float precio, precioIVA;

	 
	 printf("Introduce el precio : ");
	scanf("%f",&precio);
	/*	precio = 200;*/
	printf("precio sin iva: %.2f \n", precio);
	/*precio del producto*/
	precioIVA = precio + (precio*IVA);
	printf("precio con IVA:%.2f \n",precioIVA);
	
	
	
	
	
	return 0;	
}
